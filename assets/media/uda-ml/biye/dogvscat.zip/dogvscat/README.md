# 猫狗大战


## 描述

使用深度学习方法识别一张图片是猫还是狗。

* 输入：一张彩色图片
* 输出：是猫还是狗

## 数据

此数据集可以从 kaggle 上下载。[Dogs vs. Cats Redux: Kernels Edition](https://www.kaggle.com/c/dogs-vs-cats-redux-kernels-edition/data)

参数数据和无法识别的图片下载地址为：[github地址](https://github.com/hetaodie/dogvscat_assets.git)

## 实验环境

```
-- python 3.5.4
-- cuda 8.0
-- tensorflow-gpu (1.4.0)
-- Keras (2.0.9)
-- Ubuntu 18.11.2
-- gpu gtx 1080ti
-- cpu  12  Intel(R) Core(TM) i7-6850K CPU @ 3.60GHz
```

详细实验环境保存在导出的 conda 配置文件 `dogvscat.yml`

## 训练时长

ResNet50、InceptionV3、Xception、VGG16、VGG19
导出特征向量耗时平均每个20~30分钟

总共探索调整，花费时长大概在20小时

## 项目目录

```
.
├── report.pdf                        [报告pdf]
├── README.md                         [readme]
├── dogvscat.yml                      [实验环境配置文件]
├── image_errors                      [识别错误的图片]
├── train.html
├── train.ipynb                       [模型训练代码]
├── preproccess.html
├── gap_InceptionV3.h5                
├── gap_ResNet50.h5                
└── gap_VGG16.h5               

```



## 提交检查

* [x] 报告文件
* [x] 数据预处理代码（jupyter notebook）
* [x] 模型训练代码（jupyter notebook）
* [x] notebook 导出的 html 文件
* [x] 包含使用的库，机器硬件，机器操作系统，训练时间等数据的 README 文档（建议使用 Markdown ）


