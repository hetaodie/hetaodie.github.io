# cn-machine-learning

[点击这里](https://github.com/udacity/machine-learning/)查看项目文档的英文版本。

如果你发现任何翻译错误，或有任何建议，欢迎提交 issue 告诉我们！

